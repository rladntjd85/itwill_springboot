package com.bootstrap.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootstrapStaterApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootstrapStaterApplication.class, args);
	}

}
